import os
import json
import networkx as nx
from scorer import calculate_edge_weight
from dwm_scorer import calculate_edge_weight_dwm, node_dwm_fields
from ml_scorer import calculate_edge_weight_ml

# Resolve absolute paths relative to this script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_NETWORK_PATH = os.path.join(BASE_DIR, "data", "network.json")
DEFAULT_CVE_PATH = os.path.join(BASE_DIR, "data", "cves.json")


# --- REAL-WORLD THREAT MODELING (DROPDOWN OPTIONS) ---
# NOTE: these keys MUST exactly match node "id" values in network.json.
# (Previously these used shortened IDs like "api_gw" / "linux_kernel" /
# "core_db" / "load_balancer" / "admin_console", which do not exist in
# network.json — every node there is suffixed _1/_2/_3, or renamed
# entirely, e.g. linux_legacy_node. That caused find_attack_paths()
# to fail with "Invalid entry point" for 4 of 4 entry options and
# 1 of 4 goal options. Fixed below.)

# Maps real-world Entry Points to our specific network nodes
COMMON_ENTRY_POINTS = {
    "api_gw_1": "Public-facing web apps (Unpatched software, Insecure APIs)",
    "admin_console_1": "Phishing / Insider Threat (Stolen credentials)",
    "load_balancer_1": "Exposed infrastructure / Weak remote endpoints",
    "linux_legacy_node": "IoT / Unmanaged legacy devices on network"
}

# Maps real-world End Goals to our specific network nodes
COMMON_END_GOALS = {
    "swift_terminal": "Financial gain (Wire fraud, Cryptocurrency theft)",
    "data_warehouse": "Data theft (Customer records, Intellectual property)",
    "core_db_node_1": "Sabotage / Ransomware (Disrupting core services)",
    "web_app_1": "Botnet building / Persistence (Hijacking compute power)"
}

def get_dropdown_options():
    """
    Exposes the common entry points and end goals.
    Person 4 (API) will serve this to Person 3 (Frontend) to build the UI dropdowns.
    """
    return {
        "sources": COMMON_ENTRY_POINTS,
        "destinations": COMMON_END_GOALS
    }


# --- CORE GRAPH ENGINE ---

def build_graph(network_path=DEFAULT_NETWORK_PATH, cve_path=DEFAULT_CVE_PATH, weighting_mode="static"):
    """
    Loads network topology and grouped CVE data to construct an in-memory NetworkX directed graph.

    weighting_mode: "static" (default) uses scorer.calculate_edge_weight, the
    raw 10.0 - cvss_score inversion. "dwm" (Task 3, Person 2) uses
    dwm_scorer.calculate_edge_weight_dwm instead, which folds KEV/patch/age/
    exposure context on top of the same base CVSS before inverting. Either
    way the node's raw `cvss_score` is left untouched; "dwm" additionally
    stamps each node with `adjusted_weight` so the response can show both
    numbers side by side.
    """
    with open(network_path, "r") as f:
        network_data = json.load(f)

    # Group multiple CVEs by node_id to handle the massive dataset
    cves_lookup = {}
    if os.path.exists(cve_path):
        with open(cve_path, "r") as f:
            cve_list = json.load(f)
            for item in cve_list:
                node_id = item.get("node_id")
                if node_id:
                    if node_id not in cves_lookup:
                        cves_lookup[node_id] = []
                    cves_lookup[node_id].append(item)

    G = nx.DiGraph()

    # Add Nodes with metadata and grouped CVE scores
    for node in network_data.get("nodes", []):
        node_id = node["id"]
        node_cves = cves_lookup.get(node_id, [])

        # Determine the highest risk score on this specific server
        max_cvss = max([float(cve.get("cvss_score", 0.0)) for cve in node_cves]) if node_cves else 0.0

        node_attrs = dict(
            name=node.get("name", node_id),
            type=node.get("type", "internal"),
            software=node.get("software", "Unknown"),
            cvss_score=max_cvss,
            cves=node_cves,
            risk=max_cvss,
            weighting_mode=weighting_mode,
        )
        if weighting_mode == "dwm":
            node_attrs["adjusted_weight"] = node_dwm_fields(node_cves, node.get("type", "internal"))["adjusted_weight"]

        G.add_node(node_id, **node_attrs)

    # Add Edges with inverted risk weights
    for edge in network_data.get("edges", []):
        u = edge["from"]
        v = edge["to"]

        # Guard against edges referencing node IDs not present in "nodes"
        if u not in G or v not in G:
            continue

        target_cvss = G.nodes[v].get("cvss_score", 0.0)
        target_exposure = G.nodes[v].get("type", "internal")
        if weighting_mode == "dwm":
            weight = calculate_edge_weight_dwm(base_cvss=target_cvss, exposure=target_exposure)
        elif weighting_mode == "ml":
            weight = calculate_edge_weight_ml(base_cvss=target_cvss, exposure=target_exposure, node_degree=G.degree(v))
        else:
            weight = calculate_edge_weight(target_cvss)

        G.add_edge(u, v, protocol=edge.get("protocol", "TCP"), weight=weight)

    return G


def find_attack_paths(G, entry_node="api_gw_1", target_node="swift_terminal", top_k=1):
    """
    Calculates the highest-risk attack path(s) using Dijkstra's algorithm.
    Validates that the provided nodes actually exist in the graph.

    top_k > 1 (Task 2, Person 2): returns up to top_k ranked, loopless
    paths via networkx's shortest_simple_paths (Yen's algorithm), so
    PathList.jsx can let the user pick path #2 / #3, not just the best one.
    """
    if entry_node not in G:
        return {"error": f"Invalid entry point: {entry_node} not in network map."}
    if target_node not in G:
        return {"error": f"Invalid destination: {target_node} not in network map."}

    def _format(path):
        return {
            "path": path,
            "nodes": [G.nodes[n] for n in path],
            "total_hops": len(path) - 1,
            "total_weight": round(sum(G[path[i]][path[i + 1]]["weight"] for i in range(len(path) - 1)), 2),
        }

    try:
        if top_k <= 1:
            path = nx.dijkstra_path(G, source=entry_node, target=target_node, weight="weight")
            return [_format(path)]

        results = []
        for path in nx.shortest_simple_paths(G, source=entry_node, target=target_node, weight="weight"):
            results.append(_format(path))
            if len(results) >= top_k:
                break
        return results
    except nx.NetworkXNoPath:
        return {"error": f"No valid network path exists between {entry_node} and {target_node}."}


# --- TEST EXECUTION ---
if __name__ == "__main__":
    print("Loading Graph Engine...")
    graph = build_graph()

    print("\n--- AVAILABLE ATTACK SCENARIOS ---")
    options = get_dropdown_options()
    print("Entry Points:")
    for key, desc in options["sources"].items():
        print(f"  - [{key}]: {desc}")
    print("End Goals:")
    for key, desc in options["destinations"].items():
        print(f"  - [{key}]: {desc}")

    # Sanity-check every dropdown option actually resolves to a real node
    print("\n--- VALIDATING DROPDOWN IDS AGAINST network.json ---")
    for key in list(options["sources"].keys()) + list(options["destinations"].keys()):
        status = "OK" if key in graph else "MISSING FROM network.json"
        print(f"  [{key}] -> {status}")

    # Testing a custom scenario: Insider Threat (Phishing) -> Data Theft
    test_source = "admin_console_1"
    test_dest = "data_warehouse"

    print(f"\nCalculating simulated attack path: {test_source} -> {test_dest}...")
    paths = find_attack_paths(graph, entry_node=test_source, target_node=test_dest)

    if isinstance(paths, dict) and "error" in paths:
        print(paths["error"])
    elif paths:
        print("\n--- PREDICTED KILL CHAIN ---")
        print(f"Hops required: {paths[0]['total_hops']}")
        print(f"Path taken: {' -> '.join(paths[0]['path'])}")