"""
ml_scorer.py — Learned/ML-weighted scorer (Person 2, Task 4, stretch)
========================================================================
Not a deep learning model — a lightweight, hand-derived logistic
regression over the same feature vector DWM already has on hand:

    [cvss_score, kev_listed, days_since_published, patch_available,
     exposure_encoded, node_degree]

The point of this file is the *architecture* (a third, pluggable
weighting_mode="ml" option with the exact same drop-in signature as
dwm_scorer.calculate_edge_weight_dwm) more than model sophistication —
per the README, hand-derived coefficients are an accepted substitute for
actually training on labeled data when there's no time to collect a
labeled set.

If scikit-learn is available and a labeled CSV is ever supplied via
`train(csv_path)`, this will fit real coefficients and overwrite the
hand-derived defaults below. Until then, the defaults are used.
"""

import math
from typing import Optional

# Hand-derived coefficients (logistic regression on standardized-ish
# features). Tuned so KEV-listed + public/critical + unpatched pushes risk
# probability toward 1.0, matching the intuition DWM's multipliers encode.
_COEFFICIENTS = {
    "bias": -3.0,
    "cvss_score": 0.55,          # 0-10
    "kev_listed": 1.8,           # 0/1
    "days_since_published": 0.0009,  # per day, saturates via clipping below
    "patch_unavailable": 1.1,    # 0/1 (inverted patch_available)
    "exposure_public": 1.1,
    "exposure_critical": 1.6,
    "node_degree": 0.08,         # more connected = more valuable pivot
}

EXPOSURE_LEVELS = ("public", "internal", "critical")


def _sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


def _risk_probability(
    cvss_score: float,
    kev_listed: bool,
    days_since_published: int,
    patch_available: bool,
    exposure: str,
    node_degree: int,
) -> float:
    c = _COEFFICIENTS
    days_clamped = min(max(days_since_published, 0), 2000)  # avoid runaway logits on old CVEs
    z = (
        c["bias"]
        + c["cvss_score"] * cvss_score
        + c["kev_listed"] * (1.0 if kev_listed else 0.0)
        + c["days_since_published"] * days_clamped
        + c["patch_unavailable"] * (0.0 if patch_available else 1.0)
        + c["exposure_public"] * (1.0 if exposure == "public" else 0.0)
        + c["exposure_critical"] * (1.0 if exposure == "critical" else 0.0)
        + c["node_degree"] * min(node_degree, 20)
    )
    return _sigmoid(z)


def calculate_edge_weight_ml(
    base_cvss: float,
    kev_listed: bool = False,
    days_since_published: int = 0,
    patch_available: bool = True,
    exposure: str = "internal",
    node_degree: int = 1,
) -> float:
    """
    Same contract/signature family as dwm_scorer.calculate_edge_weight_dwm
    (with one extra optional feature, node_degree, that only this mode
    uses) so it drops into graph.py as weighting_mode="ml" with no other
    changes. Returns a Dijkstra-ready weight (lower = higher priority).
    """
    base_cvss = max(0.0, min(10.0, float(base_cvss or 0.0)))
    p = _risk_probability(
        base_cvss, kev_listed, int(days_since_published or 0), patch_available, exposure, int(node_degree or 1)
    )
    # Map risk probability (0-1, higher = more urgent) onto a 0-10 CVSS-like
    # scale, then invert the same way scorer.py / dwm_scorer.py do.
    adjusted_score = round(p * 10.0, 2)
    return max(0.1, 10.0 - adjusted_score)


def train(csv_path: str) -> Optional[dict]:
    """
    Optional: fit real coefficients from a labeled CSV
    (columns: cvss_score,kev_listed,days_since_published,patch_available,
    exposure,node_degree,label) if scikit-learn is installed. Returns the
    fitted coefficient dict on success, or None if sklearn/data aren't
    available (the hand-derived defaults above remain in effect).
    """
    try:
        import csv as _csv
        from sklearn.linear_model import LogisticRegression
    except ImportError:
        return None

    rows = []
    with open(csv_path, newline="") as f:
        for row in _csv.DictReader(f):
            rows.append(row)
    if not rows:
        return None

    X, y = [], []
    for row in rows:
        exposure = row.get("exposure", "internal")
        X.append([
            float(row.get("cvss_score", 0)),
            1.0 if row.get("kev_listed", "").lower() in ("1", "true") else 0.0,
            float(row.get("days_since_published", 0) or 0),
            0.0 if row.get("patch_available", "true").lower() in ("1", "true") else 1.0,
            1.0 if exposure == "public" else 0.0,
            1.0 if exposure == "critical" else 0.0,
            float(row.get("node_degree", 1) or 1),
        ])
        y.append(int(row.get("label", 0)))

    clf = LogisticRegression(max_iter=1000)
    clf.fit(X, y)

    global _COEFFICIENTS
    (
        cvss_c, kev_c, days_c, patch_c, pub_c, crit_c, deg_c,
    ) = clf.coef_[0]
    _COEFFICIENTS = {
        "bias": float(clf.intercept_[0]),
        "cvss_score": float(cvss_c),
        "kev_listed": float(kev_c),
        "days_since_published": float(days_c),
        "patch_unavailable": float(patch_c),
        "exposure_public": float(pub_c),
        "exposure_critical": float(crit_c),
        "node_degree": float(deg_c),
    }
    return _COEFFICIENTS


if __name__ == "__main__":
    # Sanity check: a KEV-listed, unpatched, internet-facing CVE should
    # score meaningfully higher than a quiet internal one at the same CVSS.
    hot = calculate_edge_weight_ml(9.0, kev_listed=True, days_since_published=800,
                                    patch_available=False, exposure="public", node_degree=5)
    cold = calculate_edge_weight_ml(9.0, kev_listed=False, days_since_published=10,
                                     patch_available=True, exposure="internal", node_degree=1)
    print(f"hot (should be lower weight / higher priority): {hot}")
    print(f"cold (should be higher weight / lower priority): {cold}")
    assert hot < cold, "ML scorer sanity check failed: hot path should have lower Dijkstra weight"
    print("OK")
