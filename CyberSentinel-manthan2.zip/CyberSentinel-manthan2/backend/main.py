"""
main.py — FastAPI entry point (Person 4 territory; wired here so the merged
project runs out of the box). Matches the exact contract the real frontend
(src/api/simulate.js) expects:

    GET  /options                          -> dropdown data
    POST /simulate  {entry_node, target_node} -> SSE: path, then token stream
    POST /fix       {attack_path}             -> SSE: token stream only

The frontend sends the *already-computed* attack_path object back to /fix
(the exact one /simulate emitted) rather than an entry/target pair — this
avoids any drift between what the user saw simulated and what gets patched,
and skips a redundant graph recompute.

SSE event lines are `data: {"type": "path"|"token"|"error", "data": ...}\n\n`,
terminated by a literal `data: [DONE]\n\n` line, matching src/api/simulate.js's
readSSE() parser exactly.
"""

import json
from typing import Optional, Dict, Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from graph import build_graph, find_attack_paths, get_dropdown_options
from llm import stream_attack_simulation, stream_fix_suggestions

app = FastAPI(title="CyberSentinel API")

# Wide-open CORS for hackathon/demo purposes (frontend runs on a different port).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Build the graph once per weighting mode at startup — Person 1's engine is
# pure/stateless per call, and Task 3 (Person 2) adds a second mode ("dwm")
# alongside the original static scoring, so both graphs are kept ready.
_GRAPHS = {
    "static": build_graph(weighting_mode="static"),
    "dwm": build_graph(weighting_mode="dwm"),
    "ml": build_graph(weighting_mode="ml"),  # Task 4 stretch — pluggable learned weights
}


def _graph_for(weighting_mode: str):
    return _GRAPHS.get(weighting_mode, _GRAPHS["static"])


class SimulateRequest(BaseModel):
    entry_node: Optional[str] = "api_gw_1"
    target_node: Optional[str] = "swift_terminal"
    # Task 2: which ranked path to narrate (0 = best). top_k controls how
    # many ranked paths are computed so PathList.jsx has #2/#3 to switch to.
    path_index: Optional[int] = 0
    top_k: Optional[int] = 3
    # Task 3: "static" (Person 1's original scorer) | "dwm" (this role's
    # KEV/patch/age/exposure-aware scorer).
    weighting_mode: Optional[str] = "static"


class FixRequest(BaseModel):
    attack_path: Dict[str, Any]


def _sse(event_type: str, data) -> str:
    """Formats one Server-Sent-Event line: {"type": ..., "data": ...}."""
    return f"data: {json.dumps({'type': event_type, 'data': data})}\n\n"


@app.get("/options")
def options():
    """Dropdown data for the frontend's entry/target selectors."""
    return get_dropdown_options()


@app.post("/simulate")
async def simulate(req: SimulateRequest):
    G = _graph_for(req.weighting_mode)
    top_k = max(1, req.top_k or 1, (req.path_index or 0) + 1)
    paths = find_attack_paths(G, entry_node=req.entry_node, target_node=req.target_node, top_k=top_k)

    if isinstance(paths, dict) and "error" in paths:
        async def error_stream():
            yield _sse("error", paths["error"])
            yield "data: [DONE]\n\n"
        return StreamingResponse(error_stream(), media_type="text/event-stream")

    # Task 2: select whichever ranked path the frontend asked for (falls
    # back to the best path if the index is out of range), instead of
    # always narrating path #1.
    idx = req.path_index if req.path_index is not None and req.path_index < len(paths) else 0
    selected_path = paths[idx]

    async def event_generator():
        # 1. Send the full ranked set so PathList.jsx can offer #2/#3 too.
        yield _sse("paths", paths)
        # 2. Send the selected path so the frontend can render/animate the graph.
        yield _sse("path", selected_path)
        # 3. Stream the red-team narrative token by token, for the selected path.
        async for token in stream_attack_simulation(selected_path):
            yield _sse("token", token)
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


def _node_fix(node: Dict[str, Any]) -> Dict[str, str]:
    """
    Task 1: pulls the {issue, impact, fix} remediation block off a node's
    worst (highest-CVSS) CVE — the same "worst CVE" pattern graph.py
    already uses for the node's headline cvss_score — instead of
    concatenating every node's fix into one blob.
    """
    cves = node.get("cves") or []
    if not cves:
        return {
            "issue": "No CVE is mapped to this host.",
            "impact": "Used only as a pivot/transit hop via its trust relationship with the previous node.",
            "fix": "No patch required here — verify segmentation and logging are still enforced on this hop.",
        }
    worst = max(cves, key=lambda c: float(c.get("cvss_score", 0.0)))
    remediation = worst.get("remediation")
    if remediation:
        return remediation
    # Fallback for any CVE not yet backfilled with a remediation block.
    urgency = "Fix Now" if worst.get("cvss_score", 0) >= 9 else "Fix This Week" if worst.get("cvss_score", 0) >= 7 else "Monitor"
    return {
        "issue": f"{worst.get('cve_id')} (CVSS {worst.get('cvss_score')}, {worst.get('severity')}): "
                 f"{(worst.get('description') or '').split('. ')[0]}.",
        "impact": f"Exploiting this at {node.get('name')} advances the attacker along the kill chain.",
        "fix": f"{worst.get('patch') or 'Apply the vendor patch'}. Priority: {urgency}.",
    }


@app.post("/fix")
async def fix(req: FixRequest):
    attack_path = req.attack_path

    if not attack_path or not attack_path.get("nodes"):
        async def error_stream():
            yield _sse("error", "No attack path provided to generate a fix for.")
            yield "data: [DONE]\n\n"
        return StreamingResponse(error_stream(), media_type="text/event-stream")

    node_ids = attack_path.get("path", [])
    nodes = attack_path.get("nodes", [])

    async def event_generator():
        # Task 1: stream one node_fix event per node, in path order, so
        # SafetyCard.jsx can reveal cards one at a time — no single blob.
        for i, node in enumerate(nodes):
            node_id = node_ids[i] if i < len(node_ids) else f"node_{i}"
            yield _sse("node_fix", {"node_id": node_id, **_node_fix(node)})
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.post("/fix/narrative")
async def fix_narrative(req: FixRequest):
    """
    Optional: the original free-text remediation narrative (LLM-generated,
    one blob) — kept as a separate endpoint for anyone who still wants
    prose rather than structured per-node cards.
    """
    attack_path = req.attack_path
    if not attack_path or not attack_path.get("nodes"):
        async def error_stream():
            yield _sse("error", "No attack path provided to generate a fix for.")
            yield "data: [DONE]\n\n"
        return StreamingResponse(error_stream(), media_type="text/event-stream")

    async def event_generator():
        async for token in stream_fix_suggestions(attack_path):
            yield _sse("token", token)
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
