// ─────────────────────────────────────────────────────────────────────────
// Client-side port of Person 1's backend/graph.py + backend/scorer.py.
// Runs the SAME risk-weighted Dijkstra algorithm over the SAME real
// network.json / cves.json Person 1 shipped, so the dashboard is fully
// live and correct even before Person 4's FastAPI server exists.
//
// The moment /simulate is live (see api/simulate.js), this only serves as
// the fallback path — but it will keep matching the backend exactly,
// since it's a straight port, not an approximation.
// ─────────────────────────────────────────────────────────────────────────

import network from "./network.json";
import cveList from "./cves.json";
import { calculateEdgeWeightDwm, nodeDwmFields } from "./dwmScorer";

// Maps real-world entry points to network nodes (mirrors graph.py exactly).
export const COMMON_ENTRY_POINTS = {
  api_gw_1: "Public-facing web apps (Unpatched software, Insecure APIs)",
  admin_console_1: "Phishing / Insider Threat (Stolen credentials)",
  load_balancer_1: "Exposed infrastructure / Weak remote endpoints",
  linux_legacy_node: "IoT / Unmanaged legacy devices on network",
};

// Maps real-world end goals to network nodes (mirrors graph.py exactly).
export const COMMON_END_GOALS = {
  swift_terminal: "Financial gain (Wire fraud, Cryptocurrency theft)",
  data_warehouse: "Data theft (Customer records, Intellectual property)",
  core_db_node_1: "Sabotage / Ransomware (Disrupting core services)",
  web_app_1: "Botnet building / Persistence (Hijacking compute power)",
};

// scorer.py: calculate_edge_weight — invert CVSS so high risk = low weight.
function calculateEdgeWeight(cvssScore) {
  const score = Math.max(0, Math.min(10, Number(cvssScore) || 0));
  return Math.max(0.1, 10 - score);
}

const _graphCache = new Map(); // weightingMode -> graph

/**
 * graph.py: build_graph() — builds an in-memory directed graph, grouping
 * every CVE under its node and tagging each node with its worst (max)
 * CVSS score, exactly like the Python version.
 *
 * weightingMode: "static" (default, Person 1's scorer.py) | "dwm" (Task 3
 * — folds in KEV/patch/age/exposure context on top of the raw CVSS).
 * The raw cvss_score on each node is never altered either way; "dwm" adds
 * an extra adjusted_weight field alongside it.
 */
export function buildGraph(weightingMode = "static") {
  if (_graphCache.has(weightingMode)) return _graphCache.get(weightingMode);

  const cvesByNode = {};
  for (const cve of cveList) {
    if (!cve.node_id) continue;
    (cvesByNode[cve.node_id] ??= []).push(cve);
  }

  const nodes = new Map();
  for (const n of network.nodes) {
    const nodeCves = cvesByNode[n.id] ?? [];
    const maxCvss = nodeCves.length
      ? Math.max(...nodeCves.map((c) => Number(c.cvss_score) || 0))
      : 0;
    const entry = {
      id: n.id,
      name: n.name ?? n.id,
      type: n.type ?? "internal",
      software: n.software ?? "Unknown",
      cvss_score: maxCvss,
      risk: maxCvss,
      cves: nodeCves,
      weighting_mode: weightingMode,
    };
    if (weightingMode === "dwm") {
      const dwm = nodeDwmFields(nodeCves, n.type ?? "internal");
      entry.adjusted_weight = dwm.adjusted_weight;
    }
    nodes.set(n.id, entry);
  }

  const adjacency = new Map([...nodes.keys()].map((id) => [id, []]));
  const edges = [];
  for (const e of network.edges) {
    if (!nodes.has(e.from) || !nodes.has(e.to)) continue;
    const targetNode = nodes.get(e.to);
    const weight =
      weightingMode === "dwm"
        ? calculateEdgeWeightDwm({
            baseCvss: targetNode.cvss_score,
            kevListed: false,
            daysSincePublished: 0,
            patchAvailable: true,
            exposure: targetNode.type,
          })
        : calculateEdgeWeight(targetNode.cvss_score);
    adjacency.get(e.from).push({ to: e.to, weight, protocol: e.protocol ?? "TCP" });
    edges.push({ from: e.from, to: e.to, protocol: e.protocol ?? "TCP", weight });
  }

  const graph = { nodes, adjacency, edges, weightingMode };
  _graphCache.set(weightingMode, graph);
  return graph;
}

// Binary min-heap of [dist, counter, node] tuples, mirroring networkx's
// heapq-based _dijkstra_multisource exactly (including its counter-based
// FIFO tie-break for equal distances) so results match graph.py bit-for-bit.
class MinHeap {
  constructor() {
    this.items = [];
  }
  get size() {
    return this.items.length;
  }
  push(item) {
    const items = this.items;
    items.push(item);
    let i = items.length - 1;
    while (i > 0) {
      const parent = (i - 1) >> 1;
      if (this._less(items[i], items[parent])) {
        [items[i], items[parent]] = [items[parent], items[i]];
        i = parent;
      } else break;
    }
  }
  pop() {
    const items = this.items;
    const top = items[0];
    const last = items.pop();
    if (items.length) {
      items[0] = last;
      let i = 0;
      const n = items.length;
      while (true) {
        const l = 2 * i + 1;
        const r = 2 * i + 2;
        let smallest = i;
        if (l < n && this._less(items[l], items[smallest])) smallest = l;
        if (r < n && this._less(items[r], items[smallest])) smallest = r;
        if (smallest === i) break;
        [items[i], items[smallest]] = [items[smallest], items[i]];
        i = smallest;
      }
    }
    return top;
  }
  _less(a, b) {
    // Compare by (dist, counter) like Python tuple comparison.
    return a[0] !== b[0] ? a[0] < b[0] : a[1] < b[1];
  }
}

function dijkstra(graph, source, target, blockedEdges = null) {
  const { adjacency } = graph;
  const dist = new Map();
  const seen = new Map();
  const prev = new Map();
  const heap = new MinHeap();
  let counter = 0;

  seen.set(source, 0);
  heap.push([0, counter++, source]);

  while (heap.size) {
    const [d, , v] = heap.pop();
    if (dist.has(v)) continue;
    dist.set(v, d);
    if (v === target) break;

    for (const { to, weight } of adjacency.get(v) ?? []) {
      if (blockedEdges?.has(`${v}|${to}`)) continue;
      const vuDist = dist.get(v) + weight;
      if (!seen.has(to) || vuDist < seen.get(to)) {
        seen.set(to, vuDist);
        heap.push([vuDist, counter++, to]);
        prev.set(to, v);
      }
    }
  }

  if (!dist.has(target)) return null;

  const path = [target];
  let cur = target;
  while (cur !== source) {
    cur = prev.get(cur);
    if (cur === undefined) return null;
    path.unshift(cur);
  }
  return path;
}

function toPathResult(graph, path) {
  const pathNodes = path.map((id) => graph.nodes.get(id));
  let totalWeight = 0;
  for (let i = 0; i < path.length - 1; i++) {
    const edge = graph.adjacency.get(path[i])?.find((e) => e.to === path[i + 1]);
    totalWeight += edge?.weight ?? 0;
  }
  return {
    path,
    nodes: pathNodes,
    total_hops: path.length - 1,
    total_weight: Math.round(totalWeight * 100) / 100,
    weighting_mode: graph.weightingMode,
  };
}

/**
 * Simple loopless k-shortest-paths: after finding the best path, block its
 * single highest-weight edge (the attacker's "preferred" hop) and re-run
 * Dijkstra, repeating up to k times and skipping any path already found.
 * Not Yen's algorithm (no partial-path branching) — good enough to give
 * PathList.jsx (Section 2 / Task 2) a distinct #2 and #3 ranked path for
 * the same entry/target without the O(k·V·E log V) cost of the full
 * algorithm, which this dataset's size doesn't need.
 */
function kShortestPaths(graph, source, target, k) {
  const results = [];
  const seen = new Set();
  const blocked = new Set(); // "from|to" edge keys removed for this search

  for (let attempt = 0; attempt < k * 4 && results.length < k; attempt++) {
    const path = dijkstra(graph, source, target, blocked);
    if (!path) break;
    const key = path.join(">");
    if (!seen.has(key)) {
      seen.add(key);
      results.push(path);
    }
    // Block the costliest edge on the path just found so the next run is
    // forced to divert, producing a genuinely different route.
    let worstEdge = null;
    let worstWeight = -Infinity;
    for (let i = 0; i < path.length - 1; i++) {
      const edge = graph.adjacency.get(path[i])?.find((e) => e.to === path[i + 1]);
      if (edge && edge.weight > worstWeight) {
        worstWeight = edge.weight;
        worstEdge = `${path[i]}|${path[i + 1]}`;
      }
    }
    if (worstEdge) blocked.add(worstEdge);
    else break;
  }
  return results;
}

/**
 * graph.py: find_attack_paths() — risk-weighted Dijkstra between the
 * chosen entry point and end goal. Returns the same shape as the Python
 * function: [{ path, nodes, total_hops }, ...] (ranked, best first), or
 * { error } if unreachable.
 *
 * options.weightingMode: "static" | "dwm" (Task 3)
 * options.topK: how many ranked paths to compute (default 1; PathList.jsx
 * / Task 2 asks for multiple so the user can select path #2, #3, ...).
 */
export function findAttackPaths(entryNode = "api_gw_1", targetNode = "swift_terminal", options = {}) {
  const { weightingMode = "static", topK = 1 } = options;
  const graph = buildGraph(weightingMode);
  if (!graph.nodes.has(entryNode)) {
    return { error: `Invalid entry point: ${entryNode} not in network map.` };
  }
  if (!graph.nodes.has(targetNode)) {
    return { error: `Invalid destination: ${targetNode} not in network map.` };
  }

  const paths =
    topK > 1
      ? kShortestPaths(graph, entryNode, targetNode, topK)
      : [dijkstra(graph, entryNode, targetNode)].filter(Boolean);

  if (!paths.length) {
    return { error: `No valid network path exists between ${entryNode} and ${targetNode}.` };
  }

  return paths.map((path) => toPathResult(graph, path));
}

/**
 * Task 2: re-select a specific ranked path (by index) from a set already
 * computed by findAttackPaths(..., { topK }). Falls back to index 0 if
 * out of range, so switching PathList.jsx selection never crashes.
 */
export function selectPath(pathResults, pathIndex = 0) {
  if (!Array.isArray(pathResults) || !pathResults.length) return null;
  return pathResults[pathIndex] ?? pathResults[0];
}

export function getNode(id, weightingMode = "static") {
  return buildGraph(weightingMode).nodes.get(id);
}
