import "./PathList.css";

/**
 * Task 2: shows every ranked path found between entry and target (shortest
 * first, per graphEngine's kShortestPaths / graph.py's shortest_simple_paths)
 * so the user can see the alternates, not just whichever one is narrated.
 * Clicking a path re-runs narrative + fix generation for that path.
 */
export default function PathList({ rankedPaths, pathIndex, onSelect, status, STATUS }) {
  if (!rankedPaths?.length) return null;
  const busy = status === STATUS.SIMULATING || status === STATUS.FIXING;

  return (
    <div className="path-list">
      <span className="path-list__label">Ranked paths</span>
      <div className="path-list__items">
        {rankedPaths.map((p, i) => (
          <button
            key={i}
            type="button"
            className={`path-chip ${i === pathIndex ? "is-active" : ""}`}
            onClick={() => onSelect(i)}
            disabled={busy}
            title={p.path.join(" → ")}
          >
            <span className="path-chip__rank">{i === 0 ? "Shortest" : `#${i + 1}`}</span>
            <span className="path-chip__meta">
              {p.total_hops} hops · weight {p.total_weight}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
