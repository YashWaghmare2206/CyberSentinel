import "./FixPanel.css";

/**
 * Task 1: one safety card per node, revealed in attack-path order, instead
 * of one flat fixText string. `nodeFixes` is the array of
 * {node_id, issue, impact, fix} objects streamed as `node_fix` events
 * (see useSimulation.js / localEngine.js). If a live backend / older run
 * only ever produced the flat blob (`fixText`, no node_fix events), this
 * falls back to the original single-panel rendering so nothing breaks.
 */
export default function FixPanel({ fixText, nodeFixes, status, STATUS }) {
  const visible = status !== STATUS.IDLE && status !== STATUS.SIMULATING;
  const isFixing = status === STATUS.FIXING;

  if (!visible) return null;

  const hasCards = Array.isArray(nodeFixes) && nodeFixes.length > 0;

  return (
    <div className="fix-panel">
      <div className="panel-header">
        <span className="panel-eyebrow">04 // Automated Incident Response</span>
        <h2>Auto-Fix Instructions</h2>
        {isFixing && <span className="fix-panel__spinner" aria-label="Generating" />}
      </div>

      {hasCards ? (
        <div className="fix-panel__cards">
          {nodeFixes.map((card, i) => (
            <article className="safety-card" key={`${card.node_id}-${i}`}>
              <header className="safety-card__header">
                <span className="safety-card__step">Hop {i + 1}</span>
                <span className="safety-card__node">{card.node_id}</span>
              </header>
              <dl className="safety-card__body">
                <dt>Issue</dt>
                <dd>{card.issue}</dd>
                <dt>Impact</dt>
                <dd>{card.impact}</dd>
                <dt>Fix</dt>
                <dd>{card.fix}</dd>
              </dl>
            </article>
          ))}
          {isFixing && (
            <span
              className="fix-panel__spinner fix-panel__spinner--inline"
              aria-label="Generating next card"
            />
          )}
        </div>
      ) : (
        <pre className="fix-panel__text">
          {fixText || "Generating remediation steps for every CVE in the kill chain…"}
          {isFixing && <span className="stream-cursor">▌</span>}
        </pre>
      )}
    </div>
  );
}
