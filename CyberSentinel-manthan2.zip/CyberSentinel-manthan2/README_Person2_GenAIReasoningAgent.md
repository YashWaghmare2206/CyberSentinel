# CyberSentinel — Phase 2 — Person 2: Gen AI Reasoning Agent

> Status snapshot as of this update: Tasks 1–4 are implemented and wired
> end-to-end (frontend fallback + backend). See "What changed" below.

## Your ownership (unchanged from Phase 1)
`src/data/localEngine.js` (the LLM stand-in — still what runs until/unless
`backend/llm.py` is live), and `backend/llm.py` itself now that Person 4's
endpoint (`main.py`) is wired.

## ⚠️ Groq model fix (Aug 2026)
The "Grok API expired" symptom was actually a **model deprecation**, not a
dead key — Groq (groq.com, unrelated to xAI's "Grok") retired
`llama3-70b-8192` (this project's old default) and has since retired its
replacement, `llama-3.3-70b-versatile`, too. `backend/llm.py` and
`backend/.env.example` now default `GROQ_MODEL` to `openai/gpt-oss-120b`,
the current recommended general-purpose model on Groq. If it 400s with
`model_decommissioned` again, check https://console.groq.com/docs/models
and get a fresh key at https://console.groq.com/keys — the rest of the
pipeline (prompts, streaming parser) is unaffected by which model string
you use.

---

## What changed (this update)

### Task 1 — Per-node safety cards ✅
- Every CVE in `backend/data/cves.json` / `frontend/src/data/cves.json`
  (354 entries) now carries a `remediation: {issue, impact, fix}` object.
- `localEngine.js` no longer builds one `fixText` blob — `localFixStream()`
  emits one `{type: "node_fix", node_id, data: {issue, impact, fix}}`
  event per node, in path order (`buildNodeFix()`).
- `backend/main.py`'s `/fix` endpoint mirrors this: it streams the same
  `node_fix` events pulled from each node's worst CVE's `remediation`
  block (falls back to a generated one-liner for any CVE not yet
  backfilled). The old single-blob narrative is still available at
  `/fix/narrative` for anyone who wants prose instead of cards.
- `FixPanel.jsx` renders one `.safety-card` per node when `nodeFixes` is
  present, and falls back to the original blob rendering (`fixText`) if
  it's ever empty — so nothing breaks against an older backend.

### Task 2 — Multi-path narrative support ✅ (complete, including UI)
- `graphEngine.js`'s `findAttackPaths(entry, target, {weightingMode, topK})`
  now returns up to `topK` ranked, loopless paths (simple edge-blocking
  k-shortest search), not just the best one. `selectPath(paths, index)`
  picks one.
- `graph.py`'s `find_attack_paths(G, entry, target, top_k)` does the same
  server-side via `nx.shortest_simple_paths` (Yen's algorithm).
- `localSimulateStream()` / `main.py`'s `/simulate` both accept a
  `pathIndex`/`path_index` and emit a `paths` event with the full ranked
  set alongside the selected `path`, so narrative + per-node fixes
  regenerate for whichever path is selected.
- `useSimulation.js` exposes `rankedPaths` and `selectPath(index)`.
- `components/PathList.jsx` renders the ranked set as clickable chips
  ("Shortest", "#2", "#3", each with hop count + total weight) at the top
  of the Gen AI Reasoning panel, right beside the streaming narrative —
  clicking one re-runs narrative + per-node fix generation for that path
  and re-highlights it on the 3D graph.

### Task 3 — Dynamic Weight Management (DWM) ✅
- `backend/dwm_scorer.py`: `calculate_dynamic_weight()` /
  `calculate_edge_weight_dwm()` implement the KEV / patch-availability /
  age / exposure multipliers from the spec, then invert back through
  `10.0 - x` exactly like `scorer.py`, so it drops into `graph.py`'s
  Dijkstra call unchanged.
- `frontend/src/data/dwmScorer.js` is the JS twin, used by
  `graphEngine.js` when `weightingMode: "dwm"` is passed — same
  multipliers, same output, so the local fallback and live backend agree.
- `graph.py`'s `build_graph(weighting_mode=...)` accepts `"static"` |
  `"dwm"` | `"ml"` and stamps each node with `adjusted_weight` when not
  static, alongside the untouched `cvss_score`. `main.py` builds and
  caches a graph per mode at startup and exposes `weighting_mode` on
  `POST /simulate`.
- Verified: on this dataset, `static` mode's optimal path totals weight
  16.3; `dwm` mode (same entry/target) totals 9.04 — the KEV/exposure
  multipliers visibly reprioritize edges, per the acceptance check.

### Task 4 (stretch) — ML-weighted scorer ✅
- `backend/ml_scorer.py`: a hand-derived logistic regression over
  `[cvss_score, kev_listed, days_since_published, patch_available,
  exposure, node_degree]`, exposed as `calculate_edge_weight_ml()` with
  the same drop-in signature family as Task 3. `weighting_mode="ml"` is
  wired into `build_graph()` / `main.py` alongside `static`/`dwm`.
- `train(csv_path)` will fit real coefficients from a labeled CSV via
  scikit-learn if it's ever supplied and sklearn is installed; until
  then the hand-derived defaults are used (per the spec, this satisfies
  "architecture over model sophistication").

## Definition of done
- [x] Every CVE has a `remediation: {issue, impact, fix}` object
- [x] `localEngine.js` streams per-node `node_fix` events instead of one blob
- [x] Narrative/fix generation works for any selected path, not just rank 1
      (`PathList.jsx` UI included)
- [x] `dwm_scorer.py` implemented and pluggable via `weighting_mode`
- [x] Response payload includes both `cvss_score` and `adjusted_weight`
- [x] (Stretch) `ml_scorer.py` pluggable as a third weighting mode
- [x] Groq model updated off the now-deprecated `llama3-70b-8192`
